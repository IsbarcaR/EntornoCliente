let arr=["manzana", "pera", "banana", "melocoton"];
console.log("Las frutas que hay en la ensalada son: ");
for(var i=0; i<arr.length; i++){
    console.log(arr[i]);
}